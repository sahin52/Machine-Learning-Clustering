To run the code, have a jupyter notebook and run in jupyter notebook.
The files must be in hw2_data/hac - kmeans - knn directories
Python3 is used, so it is highly recommended, also numpy must be installed.


The results are generated in jupyter notebook, so it is recommended to use jupyter notebook. Python scripts may show many pictures of plotted graphes.
